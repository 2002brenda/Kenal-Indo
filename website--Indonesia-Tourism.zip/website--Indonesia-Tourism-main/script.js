// Navigasi Mobile (Hamburger Menu)
document.addEventListener('DOMContentLoaded', function() {
    const bar = document.getElementById('bar');
    const navBar = document.getElementById('navBar');
    
    if (bar && navBar) {
        bar.addEventListener('click', function() {
            navBar.classList.toggle('active');
        });
    }
});
  