# Website Indonesia Tourism

Website ini menampilkan informasi tentang budaya dan wisata Indonesia dengan fokus pada upacara adat, tarian tradisional, dan destinasi wisata.

## Fitur Utama

### 🏠 Halaman Beranda (Home)
- **Hero Section**: Menampilkan gambar latar belakang dengan deskripsi singkat tentang Indonesia
- **Kategori Section**: Menampilkan 3 kartu utama yang bisa diklik:
  - **Upacara Adat**: Link ke halaman about.html
  - **Tarian Tradisional**: Link ke halaman tarian.html  
  - **Wisata Alam**: Link ke halaman wisata.html

### 🎭 Halaman Upacara (about.html)
- Menampilkan informasi tentang berbagai upacara adat di Indonesia
- Layout dengan gambar dan deskripsi

### 💃 Halaman Tarian (tarian.html)
- Grid layout menampilkan berbagai tarian tradisional
- Efek hover pada gambar
- Informasi detail setiap tarian

### 🏔️ Halaman Wisata (wisata.html)
- Grid layout destinasi wisata
- Sistem booking hotel sederhana
- Kalkulasi harga otomatis

## Teknologi yang Digunakan

- **HTML5**: Struktur halaman
- **CSS3**: Styling dan animasi
- **JavaScript**: Interaktivitas dan kalkulasi
- **Font Awesome**: Ikon
- **Responsive Design**: Mobile-friendly

## Fitur Responsive

- **Desktop**: Layout 3 kolom untuk kategori
- **Tablet**: Layout 2 kolom
- **Mobile**: Layout 1 kolom dengan navigasi hamburger menu

## Cara Menjalankan

1. Buka file `index.html` di browser
2. Website akan menampilkan halaman beranda dengan 3 kategori utama
3. Klik pada kartu kategori untuk menuju halaman detail
4. Gunakan menu navigasi untuk berpindah antar halaman

## Struktur File

```
├── index.html          # Halaman beranda
├── about.html          # Halaman upacara adat
├── tarian.html         # Halaman tarian tradisional
├── wisata.html         # Halaman wisata
├── style.css           # File CSS utama
├── script.js           # File JavaScript
├── images/             # Folder gambar
│   └── image1.jpg      # Gambar utama
└── README.md           # Dokumentasi
```

## Catatan

- Saat ini menggunakan gambar placeholder (`image1.jpg`) untuk semua kategori
- Untuk hasil optimal, tambahkan gambar spesifik untuk setiap kategori:
  - `images/upacara.jpg` untuk upacara adat
  - `images/tarian.jpg` untuk tarian tradisional  
  - `images/wisata.jpg` untuk wisata alam 